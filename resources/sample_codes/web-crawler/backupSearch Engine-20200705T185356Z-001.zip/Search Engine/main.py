#! handling for robots.txt
import requests
from bs4 import BeautifulSoup
from datetime import date as dt
import json
import os
'''
files:

links_to_pull: [link,link,link]
links_crawled: [[link,date],[link,date]]



Processes:
-Crawling-
	- pull a link from links_to_crawl. If not in links_crawled, execute code, else continue to next link and remove from list
	- Save HTML to .txt file in './to_parse/'
	- Eventually attempt only to visit https sites
	- If it ends in .jpg, .png, etc. don't crawl it
-Parsing-
	- Open file in './to_parse/'
	- Loop through all doc links. If not in links_to_pull, add to links_to_pull
	- Eventually check health of page. Is it written well, is it credible, backlinks? etc.
	- Create txt file from page text 
	- Move HTML file to parsed_docs and replace previous file
-Indexing-
	- dict of all search queries ever recieved (ordered by search volume?) i.e. index = {"term":{"site":score,"site":score,"site":score}}
	- regularly loop through dict and check each doc with text.count(query)
	- eventually create new index.json to speed up search speed. Only need to open one file instead of entire 
-Search-
	- open indexed query for quick comprehensive result
-Quick Index-
	- provides quick results for query that hasn't been indexed yet
'''

#seed = 'https://en.wikipedia.org/wiki/Main_Page'


# set new requests session
sess = requests.Session() # should be reset after 100 requests



def crawl(link, ufk): # visits links that have been gathered from crawled pages and download html
	url = 'https://'+link
	r = sess.get(url)
	#Check if IP has been temporarily blocked due to too many requests
	if r.status_code != 200:
		print(f'Error {r.status_code} encountered for {link}','Continuing to next link. Will attempt again later')
		return ufk, False
		#kill program command should go here
	file_name = link.replace('/','-') # need a better way to preserve url association

	# save website HTML to txt file
	with open(f'to_parse/{file_name}.txt', 'w') as f:
		f.write(r.text)

	ufk[file_name] = link # this is bad. passing it to this method uses twice as much memory as needed

	return ufk, True


def parse(doc, fn): # pull links and text from crawled pages
	#! move the 'opens' outside and pass into function. That way controller can handle frequency of open and save calls
	with open('url_filename_key.json','r') as f:
		url_filename_key = json.load(f)
	with open('links_to_crawl.json','r') as f:
		links_to_crawl = json.load(f)

	fn = fn.replace('.txt','')
	soup = BeautifulSoup(doc, 'html.parser')

	# pull links from page
	link_list = soup.find_all('a')
	for link in link_list: 
		link = link.get('href')

		# handle link variations you will encounter
		try:
			if link is None or link == '' or link[0] == '#': # remove internal links and non url links
				continue
		except:
			print('exception: ',link)
			print(link[0])

		if link[-4:].lower() in ['.jpg','.png','.gif','.svg']: # eventually use to save picture sites
			continue

		if link[:2] == '//': # standardize links to page element: '//site.domain/page:element'
			link = link.replace('//','').split(':')[0]
		elif link[0] == '/': # handle links within domain: '/page/ref'
			link = url_filename_key[fn].split('/')[0]+link

		link = link.replace('https://','')
		link = link.replace('http://','')
		if link not in links_to_crawl: # check if already in queue to crawl
			links_to_crawl.append(link)
			print(link)

	with open('url_filename_key.json','w') as f:
		json.dump(url_filename_key,f)
	with open('links_to_crawl.json','w') as f:
		json.dump(links_to_crawl,f)


	# pull text from page
	#title = soup.title.string #! find a use for this
	text = soup.find_all(text=True)
	output = ''
	blacklist = [
		'[document]',
		'noscript',
		'header',
		'html',
		'meta',
		'head', 
		'input',
		'script',
		'style'
	]
	for t in text:
		if t.parent.name not in blacklist:
			output += '{} '.format(t)

	return output
	
	'''
	structured_data = {}
	for word in text:
		try: # avoids unecessary check if key exists. Maybe more efficient
			structured_data[word] += 1
		except:
			structured_data[word] = 1
	'''

def quick_index(query): # if search query hasn't been indexed yet
	scores = [] # structured: [[url, score],[url, score]]

	for filename in os.listdir('./parsed_text/'): 
		with open(os.path.join('./parsed_text/', filename), 'r') as f:
			try: #! eventually flag exceptions w/ non unicode chars for redownload or removal
				text = f.read().lower() #! using lower every time is processor heavy
			except:
				continue
		filename = filename.replace('.txt','')
		with open('url_filename_key.json','r') as f:
			url_filename_key = json.load(f)

		# check score of exact match and word matches
		text_len = len(text.split(' ')) # Ignores new lines. More accurate method: import re and then re.split('\n| ', string)
		exact_score = text.count(query)
		word_score = 0
		for word in query.split():
			word_score += text.count(word)
		word_score = word_score/text_len # makes score a ratio of how much a word shows up compared to how many words there are
		if word_score + exact_score > 0:
			full_score = (exact_score+1)*word_score # exact score is multiplier for semi
			scores.append([url_filename_key[filename], full_score])
	scores.sort(key=lambda x: x[1]) # sort scores list by first item in each sublist
	return scores

def search(query) -> list:
	query = query.lower() # non case sensative queries. #! eventually make bool for if case sensitive or not
	#c_query = clean(query) #! strip  unecessary characters: (' " ;) etc. replace ' ' with '_'
	with open('./query_index/index.json') as f: #! open indexed queries
		search_index = json.load(f)

	if query in search_index: # check if query has already been indexed
		return search_index[query]
	else: # provide quick index and save query for later indexing
		results = quick_index(query)
		#what to do with the search
		if len(results) < 1:
			results = ['No results match your search :(']
		for res in results:
			print(res)
		print(len(results))
		return results

def index():
	pass


################## Handles Parsing ##################
def parse_controller(): #! intermediary handler for saving progress and executing. Maybe do 10 at a time then save?
	# open dict of all previously crawled links into memory
	with open('links_crawled.json', 'r') as f:
		links_crawled = json.load(f)

	# loop through every html file downloaded and parse
	for filename in os.listdir('./to_parse/'): 
		with open(os.path.join('./to_parse/', filename), 'r') as f: # open in readonly mode 
			doc_text = parse(f.read(), filename) # pulls links and raw text from html
		with open('./parsed_text/'+filename,'w') as f: # saves text for further parsing
			f.write(doc_text)
		os.rename('./to_parse/'+filename, './parsed_html/'+filename) # moves html doc from parse queue to completed

################## Handles Crawling New Sites ##################
def crawl_controller(): #! intermediary handler for saving progress and executing. Maybe do 10 at a time then save? reset session after 100 requests
	# open dict of all previously scraped links into memory for adding new links
	with open('links_crawled.json', 'r') as f:
		links_crawled = json.load(f)
	# open list of links to crawl
	with open('links_to_crawl.json','r') as f:
		links_to_crawl = json.load(f)
	# open filename url association dict
	with open('url_filename_key.json','r') as f: # preserves url relation to filenames
		url_filename_key = json.load(f)
	
	# iterator to limit crawls to 100 at a time
	i = 0

	# crawl each link, then remove from links_to_crawl
	for url in list(links_to_crawl):
		# limit subsequent requests to 100
		if i !< 100:
			break
		# if page has already been crawled, leave additional crawling to scheduled recrawl
		if url in links_crawled:
			links_to_crawl.remove(url)
			continue
		# eventually use this to index picture pages
		if link[-4:].lower() in ['.jpg','.png','.gif','.svg','mov','mp4']: 
			links_to_crawl.remove(url)
			continue


		# increase page counter
		i += 1
		# update record of links crawled and those that still need crawling
		url_filename_key,success = crawl(url, url_filename_key)
		print(url)
		if success:
			print('success')
			print()
			links_crawled[url] = dt.today().__str__()
			links_to_crawl.remove(url)
		else:
			print('failed')
			print()
	# save updated links visited
	with open('links_crawled.json', 'w') as f: 
		json.dump(links_crawled,f)
	# save updated links to visit
	with open('links_to_crawl.json', 'w') as f: 
		json.dump(links_to_crawl,f)
	# save dict of urls filename associations
	with open('url_filename_key.json','w') as f:
		json.dump(url_filename_key, f)




def main():
	#while True:
	for x in range(10):
		parse_controller() #parse all docs in parsing queue for new links
		crawl_controller() # crawls all links
	#results = search('Robin hood')

main()



################## Handles Indexing ##################


################## Handles Regular Recrawl ##################
