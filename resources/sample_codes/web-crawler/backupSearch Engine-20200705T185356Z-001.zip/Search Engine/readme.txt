Folder Structure:

-page_text-
visible text pulled from page for quick indexing

-parsed_html-
HTML pages that 

-query_index-
json files of each query that has ever been searched

-to_parse-
HTML pages that have been visited but have not had links pulled and page text isolated






Files:
-to_visit-
list of pages that need to be crawled

-links_visited-
list of all pages ever crawled and when last visited



Features to add:
